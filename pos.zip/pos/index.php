<?php
include 'config.php';
header("Location:".$siteurl."/login");